package com.satyam.qrcodescanner;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends AppCompatActivity {



     EditText scannedText;
    Button scanBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        scanBtn=findViewById(R.id.scanner);
        scannedText=findViewById(R.id.text);

        scanBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                IntentIntegrator intentIntegrator=new IntentIntegrator(MainActivity.this);
                intentIntegrator.setOrientationLocked(true);
                intentIntegrator.setPrompt("SCAN QR CODE");
                intentIntegrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
                intentIntegrator.initiateScan();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Get the scan result from the QR code scanner
        IntentResult intentResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (intentResult != null) {
            String contents = intentResult.getContents();
            if (contents != null) {
                scannedText.setText(contents);

                // Check if the scanned content is a valid URL
                if (android.util.Patterns.WEB_URL.matcher(contents).matches()) {
                    // If it's a URL, ask the user to open it in a web browser
                    showOpenLinkDialog(contents);
                } else if (isPhoneNumber(contents)) {
                    // If it's a phone number, ask the user to perform a call action
                    showCallDialog(contents);
                } else {
                    scannedText.setText(contents);
                }
            }
        }
    }

    private boolean isPhoneNumber(String text) {
        // Implement your logic to check if the text is a valid phone number
        // You can use regex or any other method to validate the phone number
        // For example, you can check if the text contains only digits and optional symbols like "+", "-", etc.
        return true; // Replace this with your actual validation logic
    }

    private void showOpenLinkDialog(final String url) {
        // Implement a dialog to ask the user if they want to open the link in a web browser
        new AlertDialog.Builder(this)
                .setTitle("Open Link")
                .setMessage("Do you want to open this link?")
                .setPositiveButton("Open", (dialog, which) -> {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(browserIntent);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showCallDialog(final String phoneNumber) {
        // Implement a dialog to ask the user if they want to make a call
        new AlertDialog.Builder(this)
                .setTitle("Call")
                .setMessage("Do you want to call this number?")
                .setPositiveButton("Call", (dialog, which) -> {
                    Intent callIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phoneNumber));
                    startActivity(callIntent);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}